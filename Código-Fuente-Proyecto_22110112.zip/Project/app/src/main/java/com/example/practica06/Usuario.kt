package com.example.practica06

class Usuario (var usuario: String= "",
               var contrasena: String= "",
                var guardarse: Boolean= false)