package com.example.practica06.adaptador

import com.example.practica06.Ropa

//Objeto que nos va a permitir conservar los objetos ropa acumulativos (en wishlist/carrito)
object ListaDeseos {
    val lista = mutableListOf<Ropa>()
    val carrito = mutableListOf<Ropa>()
}
